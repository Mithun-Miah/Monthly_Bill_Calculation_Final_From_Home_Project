// সকলের ব্যবহৃত ইউনিটের যোগফল code start
let add_btn = document.getElementById('add_btn');

add_btn.addEventListener('click', function(){
    let num1 = document.getElementById('input1').value;
    let num2 = document.getElementById('input2').value;
    let num3 = document.getElementById('input3').value;
    let num4 = document.getElementById('input4').value;
    let num5 = document.getElementById('input5').value;

    let sum = parseFloat(num1) + parseFloat(num2) + parseFloat(num3) + parseFloat(num4) + parseFloat(num5);

    document.getElementById('result').innerHTML = sum;
});
// সকলের ব্যবহৃত ইউনিটের যোগফল code end

// সকলের ব্যবহারকৃত প্রতি ইউনিটের মূল্য code start
let get_result_btn = document.getElementById('get_result_btn');

get_result_btn.addEventListener('click', function(){
    let num6 = document.getElementById('input6').value;
    let num7 = document.getElementById('input7').value;

    let divided = parseFloat(num6) / parseFloat(num7);

    document.getElementById('get_result').innerHTML = divided.toFixed(2);
});
// সকলের ব্যবহারকৃত প্রতি ইউনিটের মূল্য code end